// Define main function (script entry)

function main(config, profileName) {
  return config;
}
